Sweepforge frozen calculation bundle

Python 3.12+. Install exact requirements.lock, then run python verifier.py.
The verifier imports included source/sweepforge, not your original workspace.
Offline.html independently calculates nominal playback from frozen dimensions.
Evidence is recomputed when exporting. Review fabrication.json for drawing status.
Patterns are conceptual mm outlines, not validated hardware or a cutting prescription.
SHA256SUMS.json is an integrity manifest, not proof of authenticity.
Source code is original MIT-licensed software; see source/LICENSE.
