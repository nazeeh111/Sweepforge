#!/usr/bin/env python3
"""Recompute Sweepforge evidence using the included source; no network calls."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import sys

def main():
    if sys.version_info < (3, 12):
        raise SystemExit("Python 3.12 or later is required")
    base = Path(__file__).resolve().parent
    manifest = json.loads((base / "SHA256SUMS.json").read_text())
    for name, expected in manifest.items():
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts or "\\" in name:
            raise SystemExit("Unsafe manifest path")
        target = base / relative
        if target.is_symlink() or not target.resolve().is_relative_to(base):
            raise SystemExit("Manifest path escapes bundle")
        if hashlib.sha256(target.read_bytes()).hexdigest() != expected:
            raise SystemExit("Checksum mismatch: " + name)
    for name, version in {"numpy": "2.3.5", "scipy": "1.18.1", "mpmath": "1.3.0"}.items():
        try:
            found = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            raise SystemExit("Missing dependency: " + name + "; install requirements.lock")
        if found != version:
            raise SystemExit("Dependency version mismatch: " + name + "=" + found + "; expected " + version)
    sys.path.insert(0, str(base / "source"))
    from sweepforge.core import analyze
    request = json.loads((base / "request.json").read_text())
    design = json.loads((base / "design.json").read_text())
    claimed = json.loads((base / "evidence.json").read_text())
    actual = analyze({"request": request, "design": design}, fit=False)
    print(json.dumps(actual, sort_keys=True, indent=2, allow_nan=False))
    if actual["report"] != claimed["report"]:
        raise SystemExit("Recomputed report differs from exported evidence")
    print("Recomputed report matches. Checksums do not establish authenticity.", file=sys.stderr)

if __name__ == "__main__":
    main()
